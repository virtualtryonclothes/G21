import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from models.product import Product, db
from utils.tryon_utils import EnhancedVirtualTryOn
from werkzeug.security import generate_password_hash, check_password_hash
import cv2
import numpy as np
import mediapipe as mp
from datetime import datetime
import jwt
import secrets
import time
import sys

# Windows console encoding fix
if sys.platform.startswith('win'):
    import locale
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(16)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///virtualtry.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'uploads')

# Configure allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Initialize database
from models import db, User, Product, Cart
db.init_app(app)

def init_db():
    with app.app_context():
        try:
            # Drop all tables and recreate them
            db.drop_all()
            db.create_all()
            
            # Create products directory if it doesn't exist
            products_dir = os.path.join(app.root_path, 'static', 'products')
            os.makedirs(products_dir, exist_ok=True)
            
            # Create uploads directory if it doesn't exist
            uploads_dir = os.path.join(app.root_path, 'static', 'uploads')
            os.makedirs(uploads_dir, exist_ok=True)
            
            # Check if we already have any products
            if not Product.query.first():
                # Add sample products
                sample_products = [
                    Product(
                        name='Classic White T-Shirt',
                        description='A premium cotton t-shirt perfect for everyday wear',
                        price=29.99,
                        size_chart={'S': [36, 28], 'M': [38, 30], 'L': [40, 32], 'XL': [42, 34]},
                        image_url='products/19620598_44329692_1000.jpg',
                        category='T-Shirts',
                        try_on_enabled=True
                    ),
                    Product(
                        name='Polo Shirt',
                        description='Classic polo shirt with comfortable fit',
                        price=39.99,
                        size_chart={'S': [36, 28], 'M': [38, 30], 'L': [40, 32], 'XL': [42, 34]},
                        image_url='products/2.png',
                        category='T-Shirts',
                        try_on_enabled=True
                    ),
                    Product(
                        name='Denim Jacket',
                        description='Stylish denim jacket with a modern fit',
                        price=79.99,
                        size_chart={'S': [36, 24], 'M': [38, 25], 'L': [40, 26], 'XL': [42, 27]},
                        image_url='products/7.png',
                        category='Jackets',
                        try_on_enabled=True
                    ),
                    Product(
                        name='Formal Black Blazer',
                        description='Elegant black blazer for formal occasions',
                        price=129.99,
                        size_chart={'S': [36, 28], 'M': [38, 29], 'L': [40, 30], 'XL': [42, 31]},
                        image_url='products/R.jpeg',
                        category='Formal Wear',
                        try_on_enabled=True
                    ),
                    Product(
                        name='Casual Hoodie',
                        description='Comfortable hoodie for casual wear',
                        price=49.99,
                        size_chart={'S': [36, 26], 'M': [38, 27], 'L': [40, 28], 'XL': [42, 29]},
                        image_url='products/6.png',
                        category='Casual Wear',
                        try_on_enabled=True
                    )
                ]
                
                for product in sample_products:
                    db.session.add(product)
            
            # Check if we already have any users
            if not User.query.first():
                # Create a test user
                test_user = User(
                    name='Test User',
                    email='test@example.com',
                    password=generate_password_hash('password123')
                )
                db.session.add(test_user)
            
            # Commit all changes
            db.session.commit()
            print("Database initialized successfully!")
            
        except Exception as e:
            print(f"Error initializing database: {str(e)}")
            db.session.rollback()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            email = request.form.get('email')
            password = request.form.get('password')
            
            if not email or not password:
                flash('Please provide both email and password', 'error')
                return render_template('login.html')
            
            user = User.query.filter_by(email=email).first()
            if user and check_password_hash(user.password, password):
                session['user_id'] = user.id
                flash('Successfully logged in!', 'success')
                return redirect(url_for('products'))
            
            flash('Invalid email or password', 'error')
            return render_template('login.html')
        except Exception as e:
            app.logger.error(f"Login error: {str(e)}")
            flash('An error occurred during login', 'error')
            return render_template('login.html')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            email = request.form.get('email')
            password = request.form.get('password')
            
            if not all([name, email, password]):
                flash('Please fill in all fields', 'error')
                return render_template('register.html')
            
            if User.query.filter_by(email=email).first():
                flash('Email already registered', 'error')
                return render_template('register.html')
            
            user = User(
                name=name,
                email=email,
                password=generate_password_hash(password)
            )
            db.session.add(user)
            db.session.commit()
            
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Registration error: {str(e)}")
            flash('An error occurred during registration', 'error')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Successfully logged out!', 'success')
    return redirect(url_for('home'))

@app.route('/products')
def products():
    if 'user_id' not in session:
        flash('Please login to view products', 'error')
        return redirect(url_for('login'))
    products = Product.query.all()
    return render_template('products.html', products=products)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    if 'user_id' not in session:
        flash('Please login to view product details', 'error')
        return redirect(url_for('login'))
    product = Product.query.get_or_404(product_id)
    return render_template('product_detail.html', product=product)

@app.route('/try_on/<int:product_id>', methods=['GET', 'POST'])
def try_on(product_id):
    if 'user_id' not in session:
        flash('Please login to use virtual try-on', 'error')
        return redirect(url_for('login'))
    
    product = Product.query.get_or_404(product_id)
    result_image = None
    error = None
    
    if request.method == 'POST':
        try:
            print("\n=== Starting Virtual Try-On Process ===")
            
            if 'photo' not in request.files:
                raise ValueError('No photo uploaded')
            
            photo = request.files['photo']
            if photo.filename == '':
                raise ValueError('No photo selected')
            
            if photo and allowed_file(photo.filename):
                # Create upload directory if it doesn't exist
                upload_dir = os.path.join(app.root_path, 'static', 'uploads')
                os.makedirs(upload_dir, exist_ok=True)
                
                # Save uploaded photo with timestamp
                timestamp = int(time.time())
                filename = f"{timestamp}_{secure_filename(photo.filename)}"
                photo_path = os.path.join(upload_dir, filename)
                photo.save(photo_path)
                print(f"✓ Saved user photo to: {photo_path}")
                
                # Get product image path
                product_path = os.path.join(app.root_path, 'static', product.image_url)
                if not os.path.exists(product_path):
                    raise ValueError(f"Product image not found: {product.image_url}")
                print(f"✓ Found product image at: {product_path}")
                
                # Generate result path
                result_filename = f'result_{timestamp}_{secure_filename(photo.filename)}'
                result_path = os.path.join(upload_dir, result_filename)
                print(f"✓ Will save result to: {result_path}")
                
                # Process try-on
                tryon_system = EnhancedVirtualTryOn()
                success = tryon_system.try_on(photo_path, product_path, result_path)
                
                if success and os.path.exists(result_path):
                    # Get relative path for URL
                    result_rel_path = os.path.relpath(result_path, os.path.join(app.root_path, 'static'))
                    result_rel_path = result_rel_path.replace('\\', '/')  # Fix Windows paths
                    result_image = url_for('static', filename=result_rel_path)
                    print(f"✓ Success! Result available at: {result_image}")
                    flash('Virtual try-on completed successfully!', 'success')
                else:
                    raise ValueError('Failed to generate try-on result')
            else:
                raise ValueError('Invalid file type. Please use .png, .jpg, .jpeg, or .gif files.')
                
        except Exception as e:
            error = str(e)
            print(f"✗ Error: {error}")
            flash(f'Error: {error}', 'error')
    
    return render_template('try_on.html', 
                         product=product,
                         result_image=result_image,
                         error=error)

@app.route('/download_result/<path:filename>')
def download_result(filename):
    try:
        # Construct the full path to the result image
        upload_dir = os.path.join(app.root_path, 'static', 'uploads')
        return send_from_directory(
            upload_dir, 
            filename,
            as_attachment=True,
            download_name='virtual-tryon-result.jpg'
        )
    except Exception as e:
        flash('Error downloading the result: ' + str(e), 'error')
        return redirect(url_for('index'))

@app.after_request
def add_header(response):
    """Ensure proper caching for dynamic images"""
    if 'image' in response.mimetype:
        response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

if __name__ == '__main__':
    init_db()
    app.run(debug=True)
